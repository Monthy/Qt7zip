Qt is supplied with a number of example applications that have been
written to provide developers with examples of the Qt API in use,
highlight good programming practice, and showcase features found in each of
Qt's core technologies.


Documentation for examples can be found in the Examples section
of the Qt documentation.
